package com.example.proyectointegrador;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.proyectointegrador.datos.TrustAllHurlStack;
import com.example.proyectointegrador.datos.Usuarios;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class RegistroInvitado extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registro_invitado);

        Button btnRegistro=findViewById(R.id.btnRegistro);
        TextView lblLogin= findViewById(R.id.tvLogin);


        EditText txtNombre=findViewById(R.id.txtNombre);
        EditText txtCorreo=findViewById(R.id.txtCorreo);
        EditText txtContraseña=findViewById(R.id.txtContraseña);

        lblLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Login();            }
        });

        btnRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Spinner spinnerGenero = findViewById(R.id.spinnerGenero);
                String genero = spinnerGenero.getSelectedItem().toString();
            Registro(txtNombre.getText().toString(), txtCorreo.getText().toString(), txtContraseña.getText().toString(), genero);
            //startActivity(new Intent(RegistroInvitado.this, Activity_login.class));
            }
        });


    }

    private void Registro(String Nombre, String Correo, String Contraseña, String Genero) {
        String Url = ConseguirUrl() + "/php/backend.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        String status = json.optString("status");
                        if ("success".equals(status)) {
                            Toast.makeText(RegistroInvitado.this, "Usuario registrado correctamente", Toast.LENGTH_SHORT).show();
                        } else {
                            String mensaje = json.optString("message", "Error al registrar el usuario");
                            Toast.makeText(RegistroInvitado.this, mensaje, Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(RegistroInvitado.this, "Error al procesar la respuesta", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Log.e("Volley", "Error en la solicitud: " + error.getMessage());
                    Toast.makeText(RegistroInvitado.this, "Error de conexión", Toast.LENGTH_SHORT).show();
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("clase", "RegistrarInvitado");
                params.put("nombre", Nombre);
                params.put("correo", Correo);
                params.put("contraseña", Contraseña);
                params.put("genero", Genero);
                return params;
            }
        };

        // Agregamos la solicitud usando TrustAllHurlStack para aceptar SSL autofirmado
        Volley.newRequestQueue(this, new TrustAllHurlStack()).add(stringRequest);
    }



    private void Login(){
        startActivity(new Intent(RegistroInvitado.this, Activity_login.class));
        finish();
    }

    private String ConseguirUrl(){
        SharedPreferences sharedPreferences = getSharedPreferences("userPrefs", MODE_PRIVATE);
        String auxurl=sharedPreferences.getString("url", null);
        return auxurl;
    }
}