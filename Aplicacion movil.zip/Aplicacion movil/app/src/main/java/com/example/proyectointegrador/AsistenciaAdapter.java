package com.example.proyectointegrador;

import com.example.proyectointegrador.datos.Asistencia;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.proyectointegrador.datos.Asistencia;
import java.util.List;


public class AsistenciaAdapter extends RecyclerView.Adapter<AsistenciaAdapter.AsistenciaViewHolder> {
    private List<Asistencia> asistenciaList;

    public AsistenciaAdapter(List<Asistencia> asistenciaList) {
        this.asistenciaList = asistenciaList;
    }

    @NonNull
    @Override
    public AsistenciaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflamos el layout del item de asistencia
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_main, parent, false);
        return new AsistenciaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AsistenciaViewHolder holder, int position) {
        Asistencia asistencia = asistenciaList.get(position);

        // Asignamos los valores a las vistas del CardView
        holder.attendanceNumber.setText("Asistencia #" + (position + 1));
        holder.textDay.setText(asistencia.getDia());
        holder.textStatus.setText(asistencia.getEstado());
        holder.textUser.setText("Usuario: " + asistencia.getUsuario());
        holder.textAccessDate.setText("Fecha y Hora: " + asistencia.getFechaHora());
        holder.textAccessPoint.setText("Punto de acceso: " + asistencia.getPuntoAcceso());
    }

    @Override
    public int getItemCount() {
        return asistenciaList.size();
    }

    // Actualizamos los datos del RecyclerView
    public void updateData(List<Asistencia> newAsistenciaList) {
        this.asistenciaList = newAsistenciaList;
        notifyDataSetChanged();
    }

    public static class AsistenciaViewHolder extends RecyclerView.ViewHolder {
        TextView attendanceNumber, textDay, textStatus, textUser, textAccessDate, textAccessPoint;

        public AsistenciaViewHolder(View itemView) {
            super(itemView);
            attendanceNumber = itemView.findViewById(R.id.attendanceNumber);
            textDay = itemView.findViewById(R.id.textDay);
            textStatus = itemView.findViewById(R.id.textStatus);
            textUser = itemView.findViewById(R.id.textUser);
            textAccessDate = itemView.findViewById(R.id.textAccessDate);
            textAccessPoint = itemView.findViewById(R.id.textAccessPoint);
        }
    }
}
