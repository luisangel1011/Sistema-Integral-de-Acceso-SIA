package com.example.proyectointegrador.datos;

public class Asistencia {
    private String id;
    private String nombre;
    private String dia;
    private String estado;
    private String usuario;
    private String fechaHora;
    private String puntoAcceso;

    // Constructor
    public Asistencia(String id, String nombre, String dia, String estado, String usuario, String fechaHora, String puntoAcceso) {
        this.id = id;
        this.nombre = nombre;
        this.dia = dia;
        this.estado = estado;
        this.usuario = usuario;
        this.fechaHora = fechaHora;
        this.puntoAcceso = puntoAcceso;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDia() {
        return dia;
    }

    public String getEstado() {
        return estado;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public String getPuntoAcceso() {
        return puntoAcceso;
    }
}
