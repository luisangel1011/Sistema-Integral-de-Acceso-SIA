package com.example.proyectointegrador;

import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.proyectointegrador.datos.TrustAllHurlStack;
import com.example.proyectointegrador.datos.Usuarios;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class Activity_login extends AppCompatActivity {
    private EditText etUsername, etPassword;
    private Button btnLogin;
    private TextView btnInvitado;
    //https://192.168.60.110
    //https://192.168.1.200
    private String url="https://192.168.60.110/SIA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);
        etUsername=findViewById(R.id.etUsername);
        etPassword=findViewById(R.id.etPassword);
        btnLogin=findViewById(R.id.btnLogin);
        btnInvitado=findViewById(R.id.tvInvitado);


        checkSesion();
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String txtusername=etUsername.getText().toString();
                String txtpassword=etPassword.getText().toString();

                if(!txtusername.isEmpty() && !txtpassword.isEmpty()){
                    login(txtusername,txtpassword);
                }
                else
                    Toast.makeText(Activity_login.this, "por favor, ingresar Correo y contraseña", Toast.LENGTH_SHORT).show();
            }
        });

        btnInvitado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            RegistroInvitado();
            }
        });

    }

    private void RegistroInvitado(){
        SharedPreferences sharedPreferences = getSharedPreferences("userPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("url", url);
        editor.apply();

        // Iniciar la siguiente actividad
        startActivity(new Intent(Activity_login.this, RegistroInvitado.class));
    }

    private void login(final String txtCorreo, final String txtPassword) {
        String urlLogin = url + "/php/backend.php";

        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                urlLogin,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);

                        if (jsonObject.has("status") && jsonObject.getString("status").equals("success")) {
                            JSONObject userData = jsonObject.getJSONObject("user");

                            String id = userData.getString("id_usuario");
                            String nombre = userData.getString("nombre");
                            String correo = userData.getString("correo_electronico");
                            String tipoUsuario = userData.getString("tipo_usuario");
                            String contrasena = userData.getString("contrasena");
                            String estadoCuenta = userData.getString("estado_cuenta");
                            String fecCreacion = userData.getString("fecha_Creacion");
                            String nss = userData.optString("nss", null);

                            Usuarios usuario = new Usuarios(id, nombre, correo, tipoUsuario, contrasena, estadoCuenta, fecCreacion, nss, null);

                            if (usuario.getCorreo().toLowerCase().equals(txtCorreo.toLowerCase()) &&
                                    usuario.getContraseña().toLowerCase().equals(txtPassword.toLowerCase())) {
                                SharedPreferences sharedPreferences = getSharedPreferences("userPrefs", MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString("usuario", usuario.getid());
                                editor.putString("url", url);
                                editor.apply();

                                startActivity(new Intent(Activity_login.this, MainActivity.class));
                            } else {
                                Toast.makeText(Activity_login.this, "Credenciales incorrectas", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(Activity_login.this, jsonObject.optString("message", "Error en el inicio de sesión"), Toast.LENGTH_SHORT).show();
                        }

                    } catch (Exception e) {
                        Toast.makeText(Activity_login.this, "Error al procesar la respuesta: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        Log.e("mainActivity", "Error JSON: " + e.getMessage());
                    }
                },
                error -> {
                    Toast.makeText(Activity_login.this, "Error de red: " + error.getMessage(), Toast.LENGTH_LONG).show();
                    Log.e("mainActivity", "Volley Error: ", error);
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("clase", "GetUsuario");
                params.put("Usuario", txtCorreo);
                params.put("Contraseña", txtPassword);
                params.put("Matricula", ""); // opcional si usas correo y contraseña
                return params;
            }
        };

        Volley.newRequestQueue(this, new TrustAllHurlStack()).add(stringRequest);
    }



    private void checkSesion(){
        SharedPreferences sharedPreferences = getSharedPreferences("userPrefs", MODE_PRIVATE);
        String Usuario = sharedPreferences.getString("usuario", null);
        String auxurl=sharedPreferences.getString("url", null);

        if (Usuario != null && auxurl!=null) {
            if (auxurl.equals(url)){
                // Si ya existe el correo, redirige al home
                startActivity(new Intent(Activity_login.this, MainActivity.class));
                finish();
            }
            else {

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.remove("url");
                editor.apply();
                editor.putString("url", url);
                editor.apply();
                checkSesion();

            }

        }
        else if(auxurl==null && Usuario!=null){
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("url", url);
            editor.apply();
            checkSesion();
        }
    }



}

