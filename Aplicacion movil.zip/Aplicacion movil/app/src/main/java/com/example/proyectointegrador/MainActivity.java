package com.example.proyectointegrador;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.content.SharedPreferences;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.ComponentActivity;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.proyectointegrador.datos.TrustAllHurlStack;
import com.google.android.material.navigation.NavigationView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import android.view.MenuItem;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Button btnMenu,btngenerarQR;
    private String url="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawerLayout = findViewById(R.id.drawer_layout);

        btnMenu = findViewById(R.id.btnMenu);
        btngenerarQR=findViewById(R.id.btnGenerarQR);

        TextView nombre = findViewById(R.id.txtName);
        TextView matricula = findViewById(R.id.txtMatricula);
        TextView NSS = findViewById(R.id.txtSSN);

        nombre.setText("");
        matricula.setText("");
        NSS.setText("");

        clickVer("");

        btnMenu.setOnClickListener(v -> Menu());

        navigationView = findViewById(R.id.navigation_view);
        // Configurar clics en las opciones del menú
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                int itemId = menuItem.getItemId();

                if (itemId == R.id.menu_Inicio) {
                    Toast.makeText(MainActivity.this, "Inicio seleccionada", Toast.LENGTH_SHORT).show();
                } else if (itemId == R.id.menu_gestion_usuarios) {
                    Toast.makeText(MainActivity.this, "Gestion de usuarios seleccionada", Toast.LENGTH_SHORT).show();
                } else if (itemId == R.id.menu_control_acceso) {
                    Toast.makeText(MainActivity.this, "Control de Acceso seleccionado", Toast.LENGTH_SHORT).show();
                } else if (itemId == R.id.menu_informes) {
                    Toast.makeText(MainActivity.this, "Informes de entrada seleccionado", Toast.LENGTH_SHORT).show();
                } else if (itemId == R.id.menu_notificaciones) {
                    Toast.makeText(MainActivity.this, "Notificaciones Seleccionado", Toast.LENGTH_SHORT).show();
                } else if (itemId == R.id.menu_gestion_camaras) {
                    Toast.makeText(MainActivity.this, "Gestion de camaras", Toast.LENGTH_SHORT).show();
                } else if (itemId == R.id.menu_configuracion) {
                    Toast.makeText(MainActivity.this, "Configuracion Seleccionado", Toast.LENGTH_SHORT).show();
                }else if (itemId == R.id.menu_salir_instituto) {
                    registrarSalida(); // este es tu nuevo método
                }
                else if (itemId == R.id.menu_cerrar_sesion) {
                    Toast.makeText(MainActivity.this, "Cerrar sesion, adios", Toast.LENGTH_SHORT).show();
                    cerrarSesion();
                }

                drawerLayout.closeDrawers(); // Cerrar el menú después de seleccionar una opción
                return true;
            }
        });



    }

    private String ConseguirUrl(){
        SharedPreferences sharedPreferences = getSharedPreferences("userPrefs", MODE_PRIVATE);
        String auxurl=sharedPreferences.getString("url", null);
        return auxurl;
    }

    private void clickVer(String string) {
        url = ConseguirUrl();
        String matricula = checkSesion().toLowerCase(); // convertir a minúsculas
        TextView nombre = findViewById(R.id.txtName);
        TextView matriculaView = findViewById(R.id.txtMatricula);
        TextView NSS = findViewById(R.id.txtSSN);
        ImageView imagen = findViewById(R.id.qr_code);

        // Petición POST usando StringRequest
        StringRequest request = new StringRequest(
                Request.Method.POST,
                url + "/php/backend.php",
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);

                        if (json.getString("status").equals("success")) {
                            JSONObject user = json.getJSONObject("user");

                            nombre.setText(user.getString("nombre"));
                            matriculaView.setText(user.getString("id_usuario").toLowerCase());
                            NSS.setText(user.getString("nss"));
                        } else {
                            Toast.makeText(MainActivity.this, json.optString("message", "No se pudo obtener el usuario"), Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Error al procesar la respuesta: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    if (error.networkResponse != null) {
                        String responseBody = new String(error.networkResponse.data, java.nio.charset.StandardCharsets.UTF_8);
                        Toast.makeText(MainActivity.this, "Respuesta del servidor: " + responseBody, Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                    Log.e("mainActivity", "clickVer: " + error.getMessage());
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("clase", "GetUsuario");
                params.put("Usuario", ""); // no se busca por correo
                params.put("Contraseña", ""); // ni por contraseña
                params.put("Matricula", matricula); // solo por matrícula
                return params;
            }
        };

        Volley.newRequestQueue(this, new TrustAllHurlStack()).add(request);

        ImagenUsuario(); // Muestra la imagen del usuario

        try {
            Bitmap QR = generarqr(matricula);
            imagen.setImageBitmap(QR);
        } catch (WriterException e) {
            throw new RuntimeException(e);
        }
    }

    private void ImagenUsuario() {
        ImageView imageView = findViewById(R.id.student_photo);
        String matricula = checkSesion();

        ImageRequest imagen = new ImageRequest(
                url + "/PhotosDB/" + matricula + ".jpg",
                response -> imageView.setImageBitmap(response),
                0, 0, null, null,
                error -> {
                    // Si no encuentra imagen del usuario, muestra la por defecto
                    ImageRequest fallback = new ImageRequest(
                            url + "/PhotosDB/noExistente.jpg",
                            response1 -> imageView.setImageBitmap(response1),
                            0, 0, null, null, null
                    );
                    Volley.newRequestQueue(MainActivity.this).add(fallback);
                }
        );

        Volley.newRequestQueue(MainActivity.this, new TrustAllHurlStack()).add(imagen);
    }



    private Bitmap generarqr(String text) throws WriterException {
        MultiFormatWriter writer = new MultiFormatWriter();
        // Generar un código QR con el formato especificado (QR Code)
        BitMatrix bitMatrix = writer.encode(text, BarcodeFormat.QR_CODE, 512, 512);
        BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
        // Convertir el BitMatrix en un Bitmap para mostrarlo
        return barcodeEncoder.createBitmap(bitMatrix);
    }




    private String checkSesion(){
        SharedPreferences sharedPreferences = getSharedPreferences("userPrefs", MODE_PRIVATE);
        String Usuario = sharedPreferences.getString("usuario", null);
        return Usuario;
    }

    private void cerrarSesion(){
        SharedPreferences sharedPreferences = getSharedPreferences("userPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("usuario");
        editor.apply();

        startActivity(new Intent(MainActivity.this, Activity_login.class));
        finish();
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
    private void registrarSalida() {
        String matricula = checkSesion();
        String puntoAcceso = "Salida";
        String fechaHora = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        StringRequest request = new StringRequest(
                Request.Method.POST,
                url + "/php/backend.php",
                response -> {
                    Toast.makeText(this, "Salida registrada", Toast.LENGTH_SHORT).show();
                },
                error -> {
                    Toast.makeText(this, "Error al registrar salida", Toast.LENGTH_SHORT).show();
                    Log.e("salida", error.toString());
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("clase", "RegistrarEntrada"); // reutilizas el mismo método PHP
                params.put("FeHoAcceso", fechaHora);
                params.put("PuntoAcceso", puntoAcceso);
                params.put("Usuario", matricula);
                return params;
            }
        };

        Volley.newRequestQueue(this, new TrustAllHurlStack()).add(request);
    }

    private void Menu() {
        drawerLayout.openDrawer(GravityCompat.START);
    }

}