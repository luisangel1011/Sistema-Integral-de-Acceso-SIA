package com.example.proyectointegrador;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.proyectointegrador.datos.Asistencia;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MostrarEntradas extends AppCompatActivity {

    private RecyclerView recyclerViewAsistencias;
    private AsistenciaAdapter asistenciaAdapter;
    private List<Asistencia> asistenciaList = new ArrayList<>();
    private Spinner spinnerDias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_mostrar_entradas);

        NavigationView navigationView = findViewById(R.id.navigation_view);
        // Configurar clics en las opciones del menú
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                int itemId = menuItem.getItemId();

                if (itemId == R.id.menu_Inicio) {
                    Toast.makeText(MostrarEntradas.this, "Inicio seleccionada", Toast.LENGTH_SHORT).show();
                } else if (itemId == R.id.menu_gestion_usuarios) {
                    Toast.makeText(MostrarEntradas.this, "Gestion de usuarios seleccionada", Toast.LENGTH_SHORT).show();
                } else if (itemId == R.id.menu_control_acceso) {
                    Toast.makeText(MostrarEntradas.this, "Control de Acceso seleccionado", Toast.LENGTH_SHORT).show();
                } else if (itemId == R.id.menu_informes) {
                    Toast.makeText(MostrarEntradas.this, "Informes de entrada seleccionado", Toast.LENGTH_SHORT).show();
                } else if (itemId == R.id.menu_notificaciones) {
                    Toast.makeText(MostrarEntradas.this, "Notificaciones Seleccionado", Toast.LENGTH_SHORT).show();
                } else if (itemId == R.id.menu_gestion_camaras) {
                    Toast.makeText(MostrarEntradas.this, "Gestion de camaras", Toast.LENGTH_SHORT).show();
                } else if (itemId == R.id.menu_configuracion) {
                    Toast.makeText(MostrarEntradas.this, "Configuracion Seleccionado", Toast.LENGTH_SHORT).show();
                } else if (itemId == R.id.menu_cerrar_sesion) {
                    Toast.makeText(MostrarEntradas.this, "Cerrar sesion, adios", Toast.LENGTH_SHORT).show();

                }

                // Cerrar el menú después de seleccionar una opción
                return true;
            }
        });



        // Referencias de los elementos en el layout
        recyclerViewAsistencias = findViewById(R.id.recyclerViewAttendance);
        spinnerDias = findViewById(R.id.spinnerDays);

        // Configuramos el RecyclerView
        recyclerViewAsistencias.setLayoutManager(new LinearLayoutManager(this));
        asistenciaAdapter = new AsistenciaAdapter(asistenciaList);
        recyclerViewAsistencias.setAdapter(asistenciaAdapter);

        // Configuramos el Spinner con los días de la semana
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.days_of_week, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDias.setAdapter(adapter);

        // Cargar las asistencias desde la base de datos
        loadAsistenciasData();

        // Filtrar por día seleccionado en el Spinner
        spinnerDias.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedDay = spinnerDias.getSelectedItem().toString();
                filterAsistenciasByDay(selectedDay);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Aquí puedes manejar lo que pasa si no se selecciona nada (opcional)
            }
        });

        // Botón para registrar datos
        Button btnRegistro = findViewById(R.id.btnRegistro);
        btnRegistro.setOnClickListener(v -> {
            // Acción para registrar datos
            Toast.makeText(MostrarEntradas.this, "Registrar datos", Toast.LENGTH_SHORT).show();
        });
    }

    private String ConseguirUrl(){
        SharedPreferences sharedPreferences = getSharedPreferences("userPrefs", MODE_PRIVATE);
        String auxurl=sharedPreferences.getString("url", null);
        return auxurl;
    }

    private void loadAsistenciasData() {
        String url = ConseguirUrl(); // Reemplazar con tu URL de la API
        url = url + "/php/asistencias.php";

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            // Limpiamos la lista antes de agregar los nuevos datos
                            asistenciaList.clear();
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject asistenciaObject = response.getJSONObject(i);

                                // Obtenemos los datos de la respuesta
                                String id = asistenciaObject.getString("id");
                                String nombre = asistenciaObject.getString("nombre");
                                String dia = asistenciaObject.getString("dia");
                                String estado = asistenciaObject.getString("estado");
                                String usuario = asistenciaObject.getString("usuario");
                                String fechaHora = asistenciaObject.getString("fechaHora");
                                String puntoAcceso = asistenciaObject.getString("puntoAcceso");


                                // Creamos el objeto Asistencia
                                Asistencia asistencia = new Asistencia(id, nombre, dia, estado, usuario, fechaHora, puntoAcceso);
                                // Agregamos a la lista
                                asistenciaList.add(asistencia);
                            }
                            // Notificamos al adaptador que los datos han cambiado
                            asistenciaAdapter.notifyDataSetChanged();
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(MostrarEntradas.this, "Error al cargar las asistencias", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MostrarEntradas.this, "Error en la conexión", Toast.LENGTH_SHORT).show();
                    }
                });

        // Agregar la solicitud a la cola de Volley
        Volley.newRequestQueue(this).add(jsonArrayRequest);
    }

    // Método para filtrar las asistencias por día seleccionado en el Spinner
    private void filterAsistenciasByDay(String day) {
        List<Asistencia> filteredList = new ArrayList<>();
        for (Asistencia asistencia : asistenciaList) {
            if (asistencia.getDia().equalsIgnoreCase(day)) {
                filteredList.add(asistencia);
            }
        }
        // Actualizamos el adaptador con la lista filtrada
        asistenciaAdapter.updateData(filteredList);
    }
}