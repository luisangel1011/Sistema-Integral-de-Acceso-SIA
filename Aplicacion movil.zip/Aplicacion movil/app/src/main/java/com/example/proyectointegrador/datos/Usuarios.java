package com.example.proyectointegrador.datos;

public class Usuarios {
    private String id,nombre,Correo,TipUsuario,Contraseña,Estado_Cuenta,FecCreacion,Nss;

    public Usuarios(String id,String nombre,String Correo,String TipUsuario,String Contraseña,String Estado_Cuenta,String FecCreacion,String Nss, String Vigencia){
        this.id=id;
        this.nombre=nombre;
        this.Correo=Correo;
        this.TipUsuario=TipUsuario;
        this.Contraseña=Contraseña;
        this.Estado_Cuenta=Estado_Cuenta;
        this.FecCreacion=FecCreacion;
        this.Nss=Nss;
    }
    public String getid(){
        return id;
    }
    public String getnombre(){
        return nombre;
    }
    public String getCorreo(){
        return Correo;
    }
    public String getTipUsuario(){
        return TipUsuario;
    }
    public String getContraseña(){
        return Contraseña;
    }
    public String getEstado_Cuenta(){
        return Estado_Cuenta;
    }
    public String getFecCreacion(){
        return FecCreacion;
    }
    public String getNss(){
        return Nss;
    }

}
